Some of the gui is taken from Arktys' pack "Transparent GUI overlay 1.8.9"
Link- https://www.planetminecraft.com/texture-pack/transparent-gui-overlay-1-8-9/